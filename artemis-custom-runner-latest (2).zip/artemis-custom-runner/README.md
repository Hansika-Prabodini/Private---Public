# How to run locally

## Create conda environment

Create an environment with python 3.11.9

```sh
conda create -n artemis-runner python=3.11.9
conda activate artemis-runner
```

## Install wheels

```sh
pip install -r setup/requirements.txt
```

> Note: if updating the wheels in an existing environment run this instead
>
> ```sh
> pip install --upgrade --force-reinstall -r setup/requirements.txt
> ```

> Note: if you get the following error, you may need to explicitly link the wheels dir on install. This will happen if
> run pip install outside of the project root.
>
> ```
> Looking in links: wheels/
> WARNING: Location 'wheels/' is ignored: it is either a non-existing path or lacks a specific scheme.
> ERROR: Could not find a version that satisfies the requirement artemisopt==1.11.0rc1 (from versions: none)
> ERROR: No matching distribution found for artemisopt==1.11.0rc1
> ```
>
> ```sh
> pip install --find-links path/to/wheels -r path/to/setup/requirements.txt
> ```

## Set Env Vars

Update the environment variables in `.env.credentials` with your login details:

```sh
ARTEMIS_USERNAME="<your artemis email address>"
ARTEMIS_PASSWORD="<your artemis password>"
```

## Start the runner

Set the runner name in the build settings for your project to the same name as the `--runner-name` argument when you
start the script. This is the unique identifier that will be used to route all tasks to your runner

![Runner build settings](./img/runner-name.png)

```sh
python -m runner --runner-name xxx
```

> Note: if using the dev or staging environment, pass the `--environment` cli arg to program i.e to use the staging
> environment
>
> ```sh
> python -m runner --environment=staging --runner-name xxx
> ```
>
> All valid values can be inspected using `python -m runner --help`

### Custom Environments

By default, we fill in the required env vars for our production, staging and devlopment environments.

If you need to connect to a custom environment:

1. fill in `.env.custom` with the required variables
2. Set the environment flag to `custom` when starting the runner i.e.

```sh
python -m runner --environment=custom --runner-name xxx
```

# How to run using a docker container

##### 1. Build the image or consume it from the publicly available Dockerhub repository:

Image build (bash + git stack):

```bash
docker build --target bash -f docker/Dockerfile . -t artemis-runner:bash-latest
```

Image build (bash + python + git stack):

```bash
docker build --target python -f docker/Dockerfile . -t artemis-runner:python-latest
```

Pulling from Dockerhub:

- `docker pull artemis-runner:bash-latest`
- `docker pull artemis-runner:python-latest`

##### 2. Once the image is available on your local machine, it can be used, allowed configuration is the following.

- Enviroment variables:

  - `ARTEMIS_RUNNER_NAME`: unique identifier of the runner, it needs to match what is configured on Artemis UI, see.
    (Artemis docs link here)

  - `ARTEMIS_USERNAME`: artemis login email address

  - `ARTEMIS_PASSWORD`: artemis login password

##### 3. Run the container:

The Artemis runner is provided in a range of base images, so base support suits a variety of use-cases and scenarios.
Depending on the technology of the project to be used, selection of the base image is relevant.

| Image name                   | software            |
| ---------------------------- | ------------------- |
| artemis-runner:python-latest | python + bash + git |
| artemis-runner:bash-latest   | bash + git          |

You can run the container explicitly using docker or arrange the execution using docker compose so volume magement and
environment configuration is easier.

a) Run container using plain docker.

```bash
docker run -e ARTEMIS_USERNAME="my-email@address.com" -e ARTEMIS_PASSWORD="mypassword" -e ARTEMIS_RUNNER_NAME="my-runner-name"  artemis-runner:python-latest
```

> Note: if you wish to only pick up a subset of the tasks, you can use the `ARTEMIS_RUNNER_TASKS` env variable
>
> ```bash
> docker run -e ARTEMIS_USERNAME="my-email@address.com" -e ARTEMIS_PASSWORD="mypassword" -e ARTEMIS_RUNNER_TASKS="artemis-optimise" -e ARTEMIS_RUNNER_NAME="my-runner-name"  artemis-runner:python-latest
> # only pick up artemis-optimise tasks
> ```

b) run container using docker compose:

```yaml
version: "3"
services:
  artemis-runner:
    image: artemis-runner:python-latest
    container_name: artemis-runner
    hostname: artemis-runner
    build:
      dockerfile: ./docker/Dockerfile
      context: ./../
      target: python
    environment:
      ARTEMIS_RUNNER_NAME: my-runner
      ARTEMIS_USERNAME: my-email@address.com
      ARTEMIS_PASSWORD: mypassword
```

# Building your own runner with a custom software stack

You have two ways of proceeding:

1. Extending one of the already available images for the runner, in case the sofware stack is compatible with your
   desired software stack:

   ```dockerfile
   FROM artemis-runner:python-latest
   # install your software as additional docker layers, making the runtime environment viable to use by the configured Artemis command for the filter action.
   ```

2. Grabbing the execution binary. In case you already have a working image for your application or software stack, you
   can just reuse that image and just copy the binary for the Artemis runner and execute it by standard ENTRYPOINT or
   CMD docker methods.

   ```dockerfile
   FROM artemis-runner:base-latest as base
   COPY --from=base /dist/artemis_runner /app/artemis_runner
   # Additional sofware installation if needed by docker layers
   ENTRYPOINT ["/app/artemis_runner"]
   ```
