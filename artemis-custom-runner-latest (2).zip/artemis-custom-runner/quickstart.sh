#!/bin/bash

ARTEMIS_USERNAME=""
ARTEMIS_PASSWORD=""
ARTEMIS_RUNNER_NAME=""
ARTEMIS_PYTHON="python3.11"
ARTEMIS_SKIP_DEPS=0
ARTEMIS_ENVIRONMENT="production"

source .env.credentials

required_vars=($ARTEMIS_USERNAME $ARTEMIS_PASSWORD $ARTEMIS_RUNNER_NAME)

for element in "${required_vars[@]}"; do
  if [ -z "$element" ]; then
    echo "Please ensure you have set your ARTEMIS_USERNAME, and ARTEMIS_PASSWORD in .env.credentials"
    exit
  fi
done

function install_dependencies() {
  echo "🏹 Installing dependencies"
  echo "Getting new python $ARTEMIS_PYTHON"
  if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    if [ -f /etc/fedora-release ]; then
      sudo dnf install -y $ARTEMIS_PYTHON $ARTEMIS_PYTHON-venv
    elif grep -q -E "Debian|Ubuntu" /etc/os-release; then
      sudo add-apt-repository ppa:deadsnakes/ppa -y
      sudo apt update -y
      sudo apt install -y $ARTEMIS_PYTHON $ARTEMIS_PYTHON-venv
    else
      echo "❌ Linux Distro not supported"
      exit 1
    fi
  elif [[ "$OSTYPE" == "darwin"* ]]; then
    brew install $ARTEMIS_PYTHON
  else
    echo "❌ Unsupported OS"
    exit 1
  fi
}

function create_virtualenv() {
    ### Create virtual environment if one doesn't already exist
    # TODO: Would like to use Conda here but it isn't playing nice with wget,
    # looks like Conda can no longer be downloaded this way for commercial applications
    # https://github.com/conda/conda/issues/14005
    $ARTEMIS_PYTHON -m venv .venv
    source .venv/bin/activate
    echo "🏹 Created virtual environment $VIRTUAL_ENV"
    echo "🏹 Installing wheels"
    python -m pip install --upgrade pip
    python -m pip install --upgrade --force-reinstall -r setup/requirements.txt
}

function start_custom_runner() {
    echo "🏹 Starting Artemis custom runner"
    ### Start runner
    python -m runner --environment $ARTEMIS_ENVIRONMENT --runner-name $ARTEMIS_RUNNER_NAME
}

if [[ $ARTEMIS_SKIP_DEPS -eq 0 ]]; then
  if [ -d ".venv" ]; then
    echo "🏹 Virtual environment already exists, recreate it?"
    select strictreply in "Yes" "No"; do
      relaxedreply=${strictreply:-$REPLY}
      case $relaxedreply in
          Yes | yes | y ) install_dependencies; create_virtualenv; break;;
          No  | no  | n ) break;;
      esac
    done
  else
    echo "🏹 Virtual environment doesn't exist, creating it"
    install_dependencies
    create_virtualenv
  fi
  source .venv/bin/activate
else
  echo "🏹 ARTEMIS_SKIP_DEPS is set, skipping install dependencies step"
  source .venv/bin/activate
fi
start_custom_runner

