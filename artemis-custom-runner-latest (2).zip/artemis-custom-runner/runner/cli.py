import atexit
import os
import sys
from enum import Enum, StrEnum
from typing import Annotated, Optional

import typer
from dotenv import dotenv_values, load_dotenv
from turing_task_manager.main import log_start
from typer import Option, Typer

from runner.listeners.loki_listener import LokiListener


def set_internal_env_vars():
    # needed for now as task-manager won't start without them
    # see /turing_task_manager/utils/config.py::WorkerConfig
    os.environ["RABBITMQ_HOST"] = "localhost"
    # needed to prevent json logs in worker
    os.environ["ENV_TAG"] = "develop"
    # default cluster id for all workers connecting to loki
    os.environ["CLUSTER_ID"] = "artemis-runner"

    if sys.platform == "win32":
        os.environ["PYTHONIOENCODING"] = "UTF-8"


def restore_env(original_env: dict):
    """Restores environment variables with previous content after worker execution."""
    os.environ.clear()
    os.environ.update(original_env)


def start(worker_class, runner_ids, worker_output_root):
    """Starts the worker process."""
    log_start()
    listener = LokiListener(worker_output_root, worker_class, *runner_ids)
    listener.listen()


class Environment(str, Enum):
    """Enum hosting allowed values for Artemis' environments."""

    develop = "develop"
    staging = "staging"
    production = "production"
    custom = "custom"

    def __str__(self):
        return self.value


def create_app(worker_class, task_types):
    app = Typer()

    def load_credentials():
        return dotenv_values(f".env.credentials")

    def default_environment():
        """Obtains the system environment to target."""
        credentials = load_credentials()
        environment = credentials.get("ARTEMIS_ENVIRONMENT", Environment.production)
        environment = os.environ.get("ARTEMIS_ENVIRONMENT", environment)
        return environment

    def default_runner_name():
        """Obtains the system environment to target."""
        credentials = load_credentials()
        runner_name = credentials.get("ARTEMIS_RUNNER_NAME", None)
        runner_name = None if runner_name == "<your runner name>" else runner_name
        runner_name = os.environ.get("ARTEMIS_RUNNER_NAME", runner_name)
        if runner_name is None:
            runner_name = typer.prompt("Runner Name")
        return runner_name

    RunnerTask = StrEnum("RunnerTask", {task_type: task_type for task_type in task_types})

    @app.command()
    def start_worker(
        runner_name: Annotated[
            str,
            Option(
                default_factory=default_runner_name,
                show_default=False,
                envvar="ARTEMIS_RUNNER_NAME",
                help="Unique identifier of runner",
            ),
        ],
        environment: Annotated[
            Environment,
            Option(
                default_factory=default_environment,
                show_default=Environment.production,
                envvar="ARTEMIS_ENVIRONMENT",
                help="Environment to connect to",
            ),
        ],
        runner_tasks: Annotated[
            list[RunnerTask],
            Option(envvar="ARTEMIS_RUNNER_TASKS", help="List of tasks to run"),
        ] = list(RunnerTask),
        worker_output_root: Annotated[
            str,
            Option(
                envvar="ARTEMIS_WORKER_OUTPUT_ROOT",
                help="Directory to download worker input/output",
            ),
        ] = ".artemis",
    ):
        original_env = os.environ.copy()
        atexit.register(restore_env, original_env)

        set_internal_env_vars()

        credentials = load_credentials()

        username = credentials.get("ARTEMIS_USERNAME", None)
        username = None if username == "<your artemis email address>" else username
        username = os.environ.get("ARTEMIS_USERNAME", username)

        password = credentials.get("ARTEMIS_PASSWORD", None)
        password = None if password == "<your artemis password>" else password
        password = os.environ.get("ARTEMIS_PASSWORD", password)

        if username is None:
            credentials["ARTEMIS_USERNAME"] = username = typer.prompt("Artemis login email")

        if password is None:
            credentials["ARTEMIS_PASSWORD"] = password = typer.prompt("Artemis login password", hide_input=True)

        environment_config = dotenv_values(f".env.{environment}")
        environment_config["THANOS_USERNAME"] = username
        environment_config["THANOS_PASSWORD"] = password

        # increase default artemisopt ram limit to 8GB (default is 3GB)
        environment_config["ARTEMIS_RAM_LIMIT_MB"] = os.environ.get("ARTEMIS_RAM_LIMIT_MB", "8192")

        os.environ.update(environment_config)

        runner_ids = [f"{task}-{runner_name}" for task in runner_tasks]

        if not os.path.exists(worker_output_root):
            os.makedirs(worker_output_root)

        start(worker_class, runner_ids, worker_output_root)

    return app
