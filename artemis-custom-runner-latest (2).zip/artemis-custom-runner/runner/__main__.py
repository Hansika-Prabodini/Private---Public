import os

from runner.cli import create_app
from runner.worker import ArtemisRunner

if __name__ == "__main__":
    os.environ["ARTEMIS_OUTPUT_MODE"] = "api"
    app = create_app(ArtemisRunner(), ArtemisRunner.task_types())
    app()
