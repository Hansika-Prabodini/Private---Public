#!/usr/bin/env python3
# encoding: utf-8
"""
NOTE: This is modified version of the original file from Turing Task Manager.
A key difference is that we no longer redirect stdout/stderr from the
subprocess to ttm as this was tricky to achieve on windows.

This file defines classes that can listen to a queue, unpack a task from that
queue, then process it. If the task processing fails, the task should be
returned to the queue.
"""
# ───────────────────────────────── imports ────────────────────────────────── #
# Standard Library
import asyncio
import contextlib
import sys

if sys.platform == "win32":
    import mslex as shlex
else:
    import shlex

import json
import logging
import os
import re
import runpy
import socket
import subprocess
import traceback
from multiprocessing import Process
from pathlib import Path
from subprocess import Popen
from time import time
from typing import Any, List, Optional, Tuple, Type, TypeVar, Union

import GPUtil
import pkg_resources
import psutil
# ---------------------------------------------------------------------------- #
# Dependencies
import sentry_sdk
import turing_task_manager.logger as log
from kombu import Connection, Message
from pydantic.v1 import ValidationError
# ---------------------------------------------------------------------------- #
# HTTP Clients
from turing_task_manager.clients.loki import LokiClient, LokiSettings
from turing_task_manager.clients.loki.models import ExecutionStatus, Request, WorkerId
from turing_task_manager.constants import PROCESS_ID_ENV_VAR, TASK_ID_ENV_VAR
# Task Manager
from turing_task_manager.env_builder import EnvBuilder, WorkingEnv
from turing_task_manager.exceptions import (
    EarlyExit,
    ExceptionHandler,
    ExecutableError,
    HttpException,
    TaskAlreadyCompletedError,
    TaskAlreadyRunningError,
    TaskCancelledError,
)
from turing_task_manager.kombu import KombuMQConsumer, MQAction, RabbitmqConfig
from turing_task_manager.models import Pipe, QueuedTask, ReQueuedTask
from turing_task_manager.monitor import ExceptionThread, StoppableThread, TaskMonitor
from turing_task_manager.utils import (
    RepeatingTimer,
    WorkerConfig,
    get_cpu_count,
    get_memory_bytes,
    init_sentry,
    is_python_executable,
)
from turing_task_manager.worker import BaseWorker

# ──────────────────────────────────────────────────────────────────────────── #
logging.getLogger("amqp").setLevel(logging.WARNING)
logging.getLogger("kombu").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.ERROR)
logger = logging.getLogger(__name__)
inputs_logger = logging.getLogger(f"{__name__}.inputs_download")


# ──────────────────────────────────────────────────────────────────────────── #
TIME_FORMAT = "%d/%m/%Y, %H:%M:%S"
DEPENDENCY_REGEX = re.compile(
    os.environ.get(
        "DEPENDENCY_REGEX", "(evoml|turing|pandas|numpy|metaml|enigma|scipy)"
    ),
    flags=re.MULTILINE,
)
HEARTBEAT_INTERVAL = int(os.environ.get("LOKI_HEARTBEAT_INTERVAL", 25))

# Types
PathLike = TypeVar("PathLike", str, Path)

# ──────────────────────────────────────────────────────────────────────────── #


def run_heartbeat(worker_id: WorkerId, loki_client: LokiClient):
    """Performs heartbeat functionality"""
    loki_client.perform_heartbeat(worker_id)


def run_script(script_path, file_path, args) -> None:
    """Function to run a script using runpy."""
    parent_path = script_path if script_path.is_dir() else script_path.parent

    # Manipulate path to fake running from the script's directory
    sys.path.insert(0, str(parent_path))
    init_sentry()

    @contextlib.contextmanager
    def argv_params():
        argv_backup = sys.argv
        sys.argv = [file_path] + shlex.split(args)
        try:
            yield
        finally:
            sys.argv = argv_backup

    with argv_params():
        try:
            runpy.run_path(str(script_path), {}, "__main__")
        except Exception as exc:
            # When file exits with exception it is handled here
            print(traceback.format_exc())
            sentry_sdk.capture_exception(exc)
            raise exc
        finally:
            sentry_sdk.flush()
            init_sentry()


def run_module(script_path, file_path, args) -> None:
    """Function to run a script using runpy."""

    init_sentry()

    @contextlib.contextmanager
    def argv_params():
        argv_backup = sys.argv
        sys.argv = [file_path] + shlex.split(args)
        try:
            yield
        finally:
            sys.argv = argv_backup

    with argv_params():
        try:
            runpy.run_module(str(script_path).removeprefix("module:"), {}, "__main__")
        except Exception as exc:
            # When file exits with exception it is handled here
            print(traceback.format_exc())
            sentry_sdk.capture_exception(exc)
            raise exc
        finally:
            sentry_sdk.flush()
            init_sentry()


# Public Interface
class AbstractListener(object):
    """This abstract listener implements the core behavior of listening to
    a queue and processing tasks. As much as possible, it should use generics
    hooks that can be rewritten to fit specific implementations or projects.
    """

    # For more flexibility, the class used by an abstract Listener for each
    # components (namely: building environment, monitor outputs, handle errors)
    # can be configured on a class level
    env_builder: Type[WorkingEnv] = EnvBuilder
    folder_monitor: Type[TaskMonitor] = TaskMonitor
    exception_handler: Type[ExceptionHandler] = ExceptionHandler

    # -----------------------------------
    # Attributes declaration
    env: WorkingEnv
    rootdir: Path
    worker_class: Type[BaseWorker]
    task_types: Tuple[str]
    monitor: Optional[StoppableThread]
    queues: List[str]
    current_queue: str
    # HTTP Clients
    loki_client: LokiClient
    heartbeat_loop: RepeatingTimer

    def __init__(
        self,
        rootdir: PathLike,
        worker_class: Type[BaseWorker],
        *task_types: str,
        **kwargs,
    ):
        """A listener runs in a root-directory, where different independant
        (filesystem) environments will be created and teared down.
        It also works using a subclass of `worker.BaseWorker` that defines all
        of the specific behaviors regarding the processing of a task.
        """
        assert issubclass(worker_class, BaseWorker)
        self.worker_class = worker_class
        self.rootdir: Path = Path(rootdir)

        self.task_types: Tuple[str] = task_types

        self.process: Optional[Union[Popen, Process]] = None
        self.monitor: Optional[StoppableThread] = None

        # Instantiate the worker API infos (note: same info as notification)
        loki_settings = LokiSettings.with_env_prefix("loki")
        self.loki_client = worker_class.loki_client_class(loki_settings)

        # Get the queue names
        task_queues = [
            {
                "type": task,
                "queue": self.loki_client.get_queue_name(task),
            }
            for task in self.task_types
        ]
        self.queues = [pair["queue"] for pair in task_queues]
        self.current_queue = self.queues[0]

        # Get the worker's config from the environment
        worker_config = WorkerConfig()

        # Information about the machine
        cpus_info: Union[list, tuple] = psutil.cpu_freq(percpu=True)
        cpu_count = get_cpu_count()
        if not isinstance(cpus_info, list):
            cpus_info = [cpus_info]
        if len(cpus_info) > cpu_count:
            cpus_info = cpus_info[:cpu_count]
        try:
            gpus_info = GPUtil.getGPUs()
        except BaseException:
            gpus_info = []

        registered = self.loki_client.register_worker(
            {
                "clusterId": worker_config.cluster_id,
                "workers": task_queues,
                "hostname": socket.gethostname(),
                "databaseUrl": worker_config.thanos_host,
                "rabbitmqUrl": worker_config.rabbitmq_host,
                "sentryEnabled": worker_config.sentry_enabled,
                "cpus": {
                    "count": cpu_count,
                    "frequencies": [
                        {"minHz": freq.min, "maxHz": freq.max} for freq in cpus_info
                    ],
                },
                "gpus": [
                    {
                        "id": gpu.id,
                        "name": gpu.name,
                        "memoryInBytes": gpu.memoryTotal,
                        "driver": gpu.driver,
                    }
                    for gpu in gpus_info
                ],
                "memoryInBytes": get_memory_bytes(),
                "version": os.environ.get("VERSION"),
                "commit": os.environ.get("COMMIT_HASH"),
                "codeDependencies": [
                    {
                        "name": package.key,
                        "version": package.version,
                    }
                    for package in pkg_resources.working_set
                    if DEPENDENCY_REGEX.match(package.key)
                ],
            }
        )
        self.worker_id = registered.id
        self.cluster_id = registered.clusterId

        self.heartbeat_loop = RepeatingTimer(
            run_heartbeat,
            worker_id=self.worker_id,
            loki_client=self.loki_client,
            interval=HEARTBEAT_INTERVAL,
        )

        # Add the worker_id and cluster_id to the context
        log.add_context(
            logging.getLogger(),
            worker_id=self.worker_id,
            cluster_id=self.cluster_id,
            queue=self.queues[0],
            task_type=self.task_types[0],
            env_tag=os.environ.get("ENV_TAG"),
            commit_hash=os.environ.get("COMMIT_HASH"),
        )

        # Log startup informations
        logging.getLogger(__name__).info("worker -- start")
        registered.cpus.frequencies = registered.cpus.frequencies[:1]
        logger.debug("Worker configuration:\n%s", registered.json(indent=2))

    # ------------------------------------------------------------------------ #
    def listen(self):
        """
        Implementation specific generator listening to a queue for new tasks.
        Whenever a new task is available, it should:
        - be removed from the queue
        - be yielded
        """
        raise NotImplementedError

    # ------------------------------------------------------------------------ #
    def put_back(self, task: QueuedTask[Any]):
        """Puts back a task in the queue in case of minor error

        Args:
            task (QueuedTask[Any]): task that was unpacked from the queue
        """
        raise NotImplementedError

    # ------------------------------------------------------------------------ #
    def set_worker_status(
        self, status: str, queued_task: QueuedTask[Any] = None
    ) -> List[Request]:
        """Wrapper setting the status of the worker, and querying requests if
        any are available.
        Returns a list of requests to process.
        """
        queued = queued_task.dict(by_alias=False) if queued_task is not None else {}
        update = self.loki_client.set_worker_status(
            self.worker_id,
            status,
            queued.get("id"),
        )
        if not update.availableRequests:
            return []

        return self.loki_client.get_requests(
            self.worker_id,
            process_id=queued.get("processId"),
            task_id=queued.get("id"),
        )

    # ------------------------------------------------------------------------ #
    def _set_logging_context(self, generic_queued_task: QueuedTask[Any]):
        """Sets contextual log informations for a specific task."""
        # → dependencies are too specific (and can be huge)
        # → task params are too specific (and can be huge)
        queued = generic_queued_task.dict(by_alias=False)
        log.add_context(
            logging.getLogger(),  # The context is added to the root logger
            task_id=queued["id"],
            process_id=queued["processId"],
            process_metadata=queued["metadata"],
            task_type=queued["taskType"],
            running=False,
        )

    def _drop_logging_context(self):
        """Removes the logging context specific to a task"""
        log.remove_context(
            logging.getLogger(),
            "task_id",
            "process_id",
            "process_metadata",
            "task_type",
            "running",
        )

    # ------------------------------------------------------------------------ #
    def monitor_executable(
        self,
        worker: BaseWorker,
        env: EnvBuilder,
        threads: List[ExceptionThread],
    ):
        """Starts and monitors the subprocess (the task's executable) status.
        That monitoring consists of:
        - process stdout
        - process stderr
        - run 'maintainance' code at fixed intervals
          - check the status of the task
          - check any exception in threads

        Returns:
            The stderr of the executable
        """
        # Making sure process is not cancelled
        if worker.process_status == ExecutionStatus.cancelled:
            raise TaskCancelledError("Task cancelled during execution")

        def get_process_status(process: Union[Popen, Process]):
            """
            Gets status for different kind of processes (multiprocessing/subprocess)
            """
            if isinstance(process, Popen):
                return process.poll()
            elif isinstance(process, Process):
                return process.exitcode

        # Start sentry before process
        try:
            logger.info("→ executable start")
            self.process = process = self.start_executable(
                worker,
                env,
            )
            is_python = isinstance(process, Process)

            loop_time = 5  # seconds
            logger.debug("executing process maintenance every %ds", loop_time)
            log_start = time()

            executable_stderr = ""
            return_code = get_process_status(process)
            while return_code is None:
                # Loop as long as the select mechanism indicates there is
                # data to be read from the buffer, up to {loop_time}
                # seconds
                start = time()
                remaining = loop_time

                while remaining > 0:
                    return_code = get_process_status(process)
                    if return_code is not None:
                        break

                    # Update the time left before the next maintainance
                    remaining = max(loop_time - (time() - start), 0)

                # check for exceptions in any exception threads
                for thread in (t for t in threads if t.get_exception()):
                    raise thread.get_exception()

                # check the status of the task
                if worker.process_status == ExecutionStatus.cancelled:
                    raise TaskCancelledError("Task cancelled during execution")

        finally:
            worker_config = WorkerConfig()
            # Disable sentry after finishing task
            if worker_config.sentry_enabled:
                init_sentry()

        # get the end of process value
        return_code = get_process_status(process)

        logger.info("→ executable stop [exit %d]", return_code)

        # TODO put flag
        self.process = None  # successfully stopped the process

        # handle the return code of the executable
        if return_code != 0:
            exec_error = ExecutableError(
                "Unexpected return code",
                return_code or 1,  # None -> 1
                executable_stderr,
            )
            if not is_python:
                sentry_sdk.capture_exception(exec_error)
                sentry_sdk.flush()
                init_sentry()
            raise exec_error

    # ------------------------------------------------------------------------ #
    def prepare_worker(self, generic_queued_task: QueuedTask[Any]) -> BaseWorker:
        """Takes in a raw task and tries to validate it and instanciate a worker.

        If it's valid, returns three objects:
            - queued_task: the specific version of the generic task
            - worker: a worker instance containing task specific methods

        If it's not valid, raises an exception.
        """
        # Check the format of the fetched task
        queued_task = self.convert_task(generic_queued_task)
        task = queued_task.taskParams

        # We can create a worker, handling task-specific behaviors
        worker = self.worker_class(queued_task)
        return worker

    # ------------------------------------------------------------------------ #
    def prepare_task(self, worker: BaseWorker):
        """Takes in a worker checks if its task is ready to be processed.

        Checks if the task has been cancelled and/or it has the required
        dependencies to start.

        If it's ready, doesn't do anything. If it's not ready, raises an
        exception.
        """
        # ────────────────────── preparing the task ────────────────────── #
        queued_task = worker.queued_task

        # Check if the task has a terminal status
        task_status = self.loki_client.get_task_status(
            queued_task.id,
        )
        if task_status in [
            ExecutionStatus.failed,
            ExecutionStatus.success,
            ExecutionStatus.cancelled,
        ]:
            raise TaskAlreadyCompletedError(
                f"Task is already completed ({task_status})"
            )
        # Check if process still has to be processed (cancelled status?)
        worker.update_process_status()

        # Check if the task is ready to be processed, if not, exit handler
        status = self.loki_client.get_task_status(queued_task.id)
        if status != ExecutionStatus.ready:
            raise ValueError(
                "There should not be task statuses != `ready` in the queue"
            )

        # Check if the task is required, if not, skip the next section of
        # code and go out of handler
        required = True
        if queued_task.metadata and queued_task.metadata.get("force", False):
            logger.warning("This task was forced to run")
        elif not worker.task_required():
            logger.info("Task required ? ✗")
            raise EarlyExit()

        logger.info("Task required ? ✓")

    # ------------------------------------------------------------------------ #
    def process_task(self, generic_queued_task: QueuedTask[Any]):
        """Main method processing completely a task

        This method processes a task and only returns once the task is finished
        processing. If at any point of this process the task processing fails,
        this method is responsible for putting back the task in the queue using
        the :func:`handle_failed_task` method.

        Args:
            generic_queued_task (QueuedTask[Any]): A task to process
        """
        cls = self.__class__

        # Worker might not be created if the task is malformed. This is
        # a default value to ensure the continuity once out of the exception
        # handler
        worker = None
        with cls.exception_handler(self, generic_queued_task) as handler:
            worker_config = WorkerConfig()
            if worker_config.sentry_enabled:
                init_sentry()

            # ----------------------- prepare the task ----------------------- #
            worker = self.prepare_worker(generic_queued_task)
            self.prepare_task(worker)

            # ────────────────── official start of the task ────────────────── #
            logger.debug("↱ sent notification: running")
            # Task is running
            self.loki_client.set_task_status(worker.task_id, ExecutionStatus.running)
            # Worker is processing
            try:
                self.set_worker_status("processing", worker.queued_task)
            except HttpException as e:
                print(e.code)
                try:
                    content = e.response.json().get("detail")
                except:
                    content = None
                if (
                    content
                    and e.code == 409
                    and "current task is already running" in content
                ):
                    raise TaskAlreadyRunningError(
                        f"Task {worker.queued_task}" f" is already running"
                    )
                else:
                    raise e

            logger.info("processing task:\n%s", generic_queued_task.json(indent=2))

            # Operate in a specific environment
            # → setup is done by the EnvBuilder class
            try:
                worker.process_update_loop.start()
                with cls.env_builder(worker.queued_task, self.rootdir) as env:
                    log.update_context(
                        logging.getLogger(),
                        running=True,
                    )
                    worker.env = env

                    # ───────────────────── inputs download ────────────────────── #
                    # Download all the inputs
                    inputs_logger.info("↓ Input downloads ↓")
                    worker.monitored_run(worker.download_inputs, env)

                    # We can set the number of expected output once everything
                    # has been downloaded
                    worker.set_num_output(env)

                    # self.monitor and self.process are two variables meant to be
                    # used to close resources in case of exception.
                    # They shall be None once those resources are closed
                    # successfully.

                    # ───────────────── starting monitor thread ────────────────── #
                    # Create and start the folder monitoring thread
                    self.monitor = monitor_thread = cls.folder_monitor(
                        worker,
                        env.output_dir,
                    )

                    try:
                        monitor_thread.start()
                        # ──────────────────────────────────────────────────────────── #
                        # Starts and monitor the execution of the process
                        self.monitor_executable(worker, env, [monitor_thread])

                    finally:
                        # Ask the thread to stop, then wait for it
                        monitor_thread.stop()
                        monitor_thread.join()

                    # Check for a monitor exception that might have happened after
                    # process exit
                    if monitor_thread.get_exception():
                        raise monitor_thread.get_exception()

                    self.monitor = None  # successfully stopped the thread

                # → teardown is done by the EnvBuilder class, maybe in a thread
            finally:
                worker.process_update_loop.stop()
        # → the exception handler handles any exceptions

        # As many things can happen during processing, the handler gives us the
        # status of the task
        status = handler.get_task_status()

        # ------------------------ call on-drop hook ------------------------- #
        if status in (ExecutionStatus.failed, ExecutionStatus.cancelled) and (
            worker is not None
        ):
            logger.info("→ calling worker's on_failure")
            try:
                worker.on_failure()
            except BaseException as any_exception:
                # Catching any exception there, logging it, then continue. The
                # task is already a failure anyway.
                logger.error(
                    "Exception caught in worker's 'on_failure':\n%s",
                    any_exception,
                )

        # ----------------------- send a notification ------------------------ #
        if (
            status
            and status != ExecutionStatus.pending
            and status != ExecutionStatus.requeued
        ):
            logger.debug("↱ sent notification: %s", status)
            try:
                self.loki_client.set_task_status(generic_queued_task.id, status)
            except HttpException as sce:
                logger.error("Could not send the failure notification:\n%s", sce)

        return status, handler

    # ------------------------------------------------------------------------ #
    @staticmethod
    def json_to_task(_json: dict) -> Union[QueuedTask, ReQueuedTask, None]:
        """This method is responsible for converting a json, obtained in a
        queue, to a :class:`QueuedTask` or :class:`ReQueuedTask`.
        It should as well handle the case where the json has an unexpected
        format.

        Args:
            _json (dict):
                A json message, extracted from a queue. It should follow the
                format of either :class:`ReQueuedTask` or :class:`QueuedTask`,
                but we do consider the case where this json might be corrupted /
                malformed.

        Returns:
            This method returns either a :class:`ReQueuedTask`,
            :class:`QueuedTask`, or None if an error occured. Please note that a
            :class:`ReQueuedTask` is also an instance of :class:`QueuedTask`.
        """
        # First try to cast to re-queued task. Nothing is wrong if we can't.
        try:
            task = ReQueuedTask[Any](**_json)
            return task
        except ValidationError as _:
            ...

        # Then try to cast to queued-task. This time, if it fails, we log the
        # error.
        try:
            task = QueuedTask[Any](**_json)
            return task
        except ValidationError as v_e:
            logger.error(
                "Validation Error when unpacking the task from the queue:\n%s",
                v_e,
            )
        return None

    # ------------------------------------------------------------------------ #
    @staticmethod
    def convert_task(task: QueuedTask[Any]) -> Union[QueuedTask, ReQueuedTask]:
        """Converts a generic task container to a specific task container

        This abstract listener is supposed to handle any number of tasks (A, B,
        ...). It extracts generic task containers (:class:`QueuedTask`) from the
        queue. That container contains the type of task.
        This method converts the generic container to a specific container
        corresponding to the task contained.

        For example, it can convert `t: QueuedTask[Any]` to `t: QueuedTask[C]`
        if the task is `C`.

        Args:
            task (QueuedTask): generic container to convert
        """
        _type: str = task.taskType

        if isinstance(task, ReQueuedTask):
            return ReQueuedTask[Any](**task.dict(by_alias=True))
        return QueuedTask[Any](**task.dict(by_alias=True))

    # ------------------------------------------------------------------------ #
    # To start the executable, we use a dispatch to adapt the input to each
    # different executable
    @staticmethod
    def start_executable(
        worker: BaseWorker, env: EnvBuilder, stdout=None, stderr=None
    ) -> Union[subprocess.Popen, Process]:
        """
        Uses :attr:`env.executable` and :method:`BaseWorker.executable_inputs`
        to find which bash script should be run, and starts it, returning
        a :class:`subprocess.Popen` instance
        """
        path, inputs_str = worker.executable_inputs(env)
        inputs_list = shlex.split(inputs_str.strip())

        is_python_module = str(path).startswith("module:")
        if is_python_module:
            is_python = False
        else:
            exec_path: Path = path.expanduser().resolve()

            # Check that the provided executable is valid
            tests = {
                "exists": exec_path.exists(),
                "is_file": exec_path.is_file(),
                "has_exec": os.access(exec_path, os.X_OK),
            }
            is_python = is_python_executable(exec_path)

            if not (all(tests.values()) or is_python):
                raise FileNotFoundError(
                    "Provided executable path ({0}) is not valid [{1}]".format(
                        exec_path,
                        ", ".join(
                            "{0}: {1}".format(test, "✓" if value else "✗")
                            for (test, value) in tests.items()
                        ),
                    )
                )
            if exec_path.suffix not in (".sh", ".py") or not is_python:
                logger.warning("the path is expected to be *.{sh,py} in most cases")

        os.environ[TASK_ID_ENV_VAR] = env.task.id
        os.environ[PROCESS_ID_ENV_VAR] = env.task.processId

        if is_python or is_python_module:
            return AbstractListener.create_python_process(path, inputs_str)

        logger.debug("executable: (%s)", str(exec_path))
        logger.debug("command inputs: [%s]", " ".join(inputs_list))
        commands_list = [str(exec_path), *inputs_list]
        return subprocess.Popen(
            commands_list,
            env=os.environ,
            stdout=stdout,
            stderr=stderr,
            cwd=str(exec_path.parent),
            encoding="utf-8",
        )

    @staticmethod
    def create_python_process(
        script_path: Union[Path, str],
        args: str,
    ) -> Process:
        """Creates a process running a python script file using multiprocessing."""

        is_module = str(script_path).startswith("module:")

        if not is_module:
            script_path = Path(script_path).absolute()

        if is_module:
            r = run_module
        else:
            r = run_script

        process = Process(target=r, args=(script_path, str(script_path), args))
        process.start()
        return process


# ──────────────────────────────────────────────────────────────────────────── #
class RMQListener(AbstractListener):
    """Implementation using RabbitMQ (as the abstract listener is queue
    agnostic).
    """

    def __init__(self, rootdir: str, worker_class, *args, **kwargs):
        super().__init__(rootdir, worker_class, *args, **kwargs)
        assert len(self.task_types) == 1  # currently assuming a single task type

    # ------------------------------------------------------------------------ #
    def listen(self):
        """
        Implementation specific generator listening to a queue for new tasks.
        Whenever a new task is available, it should:
        - be removed from the queue
        - be yielded

        This listener is using a Rabbit MQ queue to implement this method.
        """
        rmq_config = RabbitmqConfig.with_env_prefix("rabbitmq")
        with Connection(**rmq_config.to_kombu_params()) as conn:
            event_loop = asyncio.get_event_loop()
            consumer = KombuMQConsumer(
                f"{self.queues[0]}.*",
                consume_func=self.run,
                loop=event_loop,
                connection=conn,
                consumer_tag=self.worker_id,
            )
            self.set_worker_status("ready")
            try:
                self.heartbeat_loop.start()
                consumer.run()
            finally:
                self.heartbeat_loop.stop()

    # ------------------------------------------------------------------------ #
    def run(self, message: Message) -> Optional[MQAction]:
        """The main method of the worker class, listening and processing tasks
        as long as tasks are provided by the worker's :func:`listen` method.
        Returns True to ACK and False to NACK
        """
        body = message.body
        generic_queued_task = self.json_to_task(json.loads(body))
        self._set_logging_context(generic_queued_task)

        logger.info("received task:\n%s", generic_queued_task.json(indent=2))

        # -------------------- acknowledge the task ? -------------------- #
        logger.info("consuming the task: \x1b[32m✓\x1b[0m")

        # ----------------------- process the task ----------------------- #
        status, handler = self.process_task(generic_queued_task)

        # ------------------------- logging -------------------------- #
        log_method = logger.info if handler.ready else logger.debug

        # outcome
        if not handler.ready:
            outcome = "not ready"
        elif handler.failed:
            outcome = "\x1b[31m✗ failure\x1b[0m"
        elif handler.already_completed:
            outcome = "\x1b[33m⚠ already completed\x1b[0m"
        elif handler.already_running:
            outcome = "\x1b[33m⚠ already running\x1b[0m"
        else:
            outcome = "\x1b[32m✓ success\x1b[0m"

        # requeue
        if handler.requeued:
            requeue = "⟳ re-queue"
        elif handler.failed:
            requeue = "\x1b[1m✗ dropped\x1b[0m"
        else:
            requeue = "\x1b[32m✓ consumed\x1b[0m"
        log_method("%s - %s", outcome, requeue)

        # ---------------------------------------------------------------- #
        self._drop_logging_context()

        # Finally, set the worker to ready again
        # Note: the task is finished, so no need to communicate the process id
        # or task id
        self.set_worker_status("ready")

        if handler.requeued:
            return MQAction.REQUEUE
        return None
