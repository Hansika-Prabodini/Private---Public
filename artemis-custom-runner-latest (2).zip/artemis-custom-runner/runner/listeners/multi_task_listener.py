from .ttm_listener import (
    DEPENDENCY_REGEX,
    HEARTBEAT_INTERVAL,
    AbstractListener,
    BaseWorker,
    GPUtil,
    LokiSettings,
    Optional,
    Path,
    PathLike,
    Popen,
    Process,
    RepeatingTimer,
    StoppableThread,
    Type,
    Union,
    WorkerConfig,
    get_cpu_count,
    get_memory_bytes,
    log,
    logger,
    logging,
    os,
    pkg_resources,
    psutil,
    run_heartbeat,
    socket,
)


class MultiTaskListener(AbstractListener):
    def __init__(
        self,
        rootdir: str,
        worker_class: Type[BaseWorker],
        *task_types: PathLike,
        **kwargs,
    ):
        # Copy of AbstractListener __init__, minus the assert on worker_class
        self.worker_class = worker_class
        self.rootdir: Path = Path(rootdir)

        self.task_types: tuple[str, ...] = task_types

        self.process: Optional[Union[Popen, Process]] = None
        self.monitor: Optional[StoppableThread] = None

        # Instantiate the worker API infos (note: same info as notification)
        loki_settings = LokiSettings.with_env_prefix("loki")
        self.loki_client = worker_class.loki_client_class(loki_settings)

        # Get the queue names
        task_queues = [
            {
                "type": task,
                "queue": self.loki_client.get_queue_name(task),
            }
            for task in self.task_types
        ]
        self.queues = [pair["queue"] for pair in task_queues]
        self.current_queue = self.queues[0]

        # Get the worker's config from the environment
        worker_config = WorkerConfig()

        # Information about the machine
        cpus_info: Union[list, tuple] = psutil.cpu_freq(percpu=True)
        cpu_count = get_cpu_count()
        if not isinstance(cpus_info, list):
            cpus_info = [cpus_info]
        if len(cpus_info) > cpu_count:
            cpus_info = cpus_info[:cpu_count]
        try:
            gpus_info = GPUtil.getGPUs()
        except BaseException:
            gpus_info = []

        registered = self.loki_client.register_worker(
            {
                "clusterId": worker_config.cluster_id,
                "workers": task_queues,
                "hostname": socket.gethostname(),
                "databaseUrl": worker_config.thanos_host,
                "rabbitmqUrl": worker_config.rabbitmq_host,
                "sentryEnabled": worker_config.sentry_enabled,
                "cpus": {
                    "count": cpu_count,
                    "frequencies": [{"minHz": freq.min, "maxHz": freq.max} for freq in cpus_info],
                },
                "gpus": [
                    {
                        "id": gpu.id,
                        "name": gpu.name,
                        "memoryInBytes": gpu.memoryTotal,
                        "driver": gpu.driver,
                    }
                    for gpu in gpus_info
                ],
                "memoryInBytes": get_memory_bytes(),
                "version": os.environ.get("VERSION"),
                "commit": os.environ.get("COMMIT_HASH"),
                "codeDependencies": [
                    {
                        "name": package.key,
                        "version": package.version,
                    }
                    for package in pkg_resources.working_set
                    if DEPENDENCY_REGEX.match(package.key)
                ],
            }
        )
        self.worker_id = registered.id
        self.cluster_id = registered.clusterId

        self.heartbeat_loop = RepeatingTimer(
            run_heartbeat,
            worker_id=self.worker_id,
            loki_client=self.loki_client,
            interval=HEARTBEAT_INTERVAL,
        )

        # Add the worker_id and cluster_id to the context
        log.add_context(
            logging.getLogger(),
            worker_id=self.worker_id,
            cluster_id=self.cluster_id,
            queue=self.queues[0],
            task_type=self.task_types[0],
            env_tag=os.environ.get("ENV_TAG"),
            commit_hash=os.environ.get("COMMIT_HASH"),
        )

        # Log startup informations
        logging.getLogger(__name__).info("worker -- start")
        registered.cpus.frequencies = registered.cpus.frequencies[:1]
        logger.debug("Worker configuration:\n%s", registered.json(indent=2))
