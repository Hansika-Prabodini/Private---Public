import logging
import sys
from dataclasses import dataclass
from time import sleep
from typing import Optional

from artemis_tools.clients.auth import AuthLokiClient
from turing_task_manager.clients import HttpException
from turing_task_manager.clients.loki import LokiSettings
from turing_task_manager.kombu import MQAction
from turing_task_manager.listener import AbstractListener

from .multi_task_listener import MultiTaskListener

logger = logging.getLogger(__name__)


@dataclass
class Message:
    body: dict


class LokiListener(MultiTaskListener):
    def __init__(self, rootdir: str, worker_class, *task_types, **kwargs):
        super().__init__(rootdir, worker_class, *task_types, **kwargs)

    def listen(self):
        settings = LokiSettings.with_env_prefix("loki")
        poll_timeout = 5
        settings.read_timeout = poll_timeout + 5
        loki = AuthLokiClient(settings)

        try:
            self.heartbeat_loop.start()
            logger.info(f"Polling for tasks on [{' '.join(self.task_types)}] with timeout {poll_timeout}s")
            while True:
                for task_type in self.task_types:
                    try:
                        # TODO: need to merge PR adding timeout qeury param to dequeue endpoint
                        # for now, it is internally hardcoded to 5s
                        body = loki.post(f"/tasks/{task_type}/dequeue?timeout={poll_timeout}")
                    except HttpException as e:
                        code = e.response.status_code
                        detail = e.response.json().get("detail")
                        if code == 404 and detail == "no task found":
                            continue
                        else:
                            logger.error(f"Error fetching task:\n {e}")
                            sys.exit(1)

                    self.run(Message(body))

                # sleep(5)
        finally:
            self.heartbeat_loop.stop()

    def run(self, message: Message) -> Optional[MQAction]:
        """The main method of the worker class, listening and processing tasks
        as long as tasks are provided by the worker's :func:`listen` method.

        Returns True to ACK and False to NACK
        """
        body = message.body
        generic_queued_task = self.json_to_task(body)
        self._set_logging_context(generic_queued_task)

        logger.info("received task:\n%s", generic_queued_task.json(indent=2))

        # -------------------- acknowledge the task ? -------------------- #
        logger.info("consuming the task: \x1b[32m✓\x1b[0m")

        # ----------------------- process the task ----------------------- #
        status, handler = self.process_task(generic_queued_task)

        # ------------------------- logging -------------------------- #
        log_method = logger.info if handler.ready else logger.debug

        # outcome
        if not handler.ready:
            outcome = "not ready"
        elif handler.failed:
            outcome = "\x1b[31m✗ failure\x1b[0m"
        elif handler.already_completed:
            outcome = "\x1b[33m⚠ already completed\x1b[0m"
        elif handler.already_running:
            outcome = "\x1b[33m⚠ already running\x1b[0m"
        else:
            outcome = "\x1b[32m✓ success\x1b[0m"

        # requeue
        if handler.requeued:
            requeue = "⟳ re-queue"
        elif handler.failed:
            requeue = "\x1b[1m✗ dropped\x1b[0m"
        else:
            requeue = "\x1b[32m✓ consumed\x1b[0m"
        log_method("%s - %s", outcome, requeue)

        # ---------------------------------------------------------------- #
        self._drop_logging_context()

        # Finally, set the worker to ready again
        # Note: the task is finished, so no need to communicate the process id
        # or task id
        self.set_worker_status("ready")

        if handler.requeued:
            return MQAction.REQUEUE
        return None
