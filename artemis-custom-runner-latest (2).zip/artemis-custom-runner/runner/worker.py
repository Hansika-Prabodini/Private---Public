from typing import Type

from artemis_tools.clients.auth import AuthLokiClient, AuthTaskBoundLokiClient
from artemisopt.workers.filter.__main__ import ArtemisFilterWorker
from artemisopt.workers.optimise.__main__ import ArtemisOptimiseWorker
from artemisopt.workers.utility.__main__ import ArtemisUtilityWorker
from turing_task_manager.clients import LokiClient
from turing_task_manager.models import QueuedTask


class PrefixMatch(str):
    def __eq__(self, prefix: object) -> bool:
        if type(prefix) is not str:
            return False
        return self.startswith(prefix)


class ArtemisRunner:

    # NOTE: these must be the samp as client classes in the workers
    # Perhaps the AbstractListener shouldn't rely on this to get the client
    loki_client: LokiClient
    loki_client_class = AuthLokiClient
    task_bound_loki_client_class = AuthTaskBoundLokiClient

    WORKER_MAPPING = {
        "artemis-utility": ArtemisUtilityWorker,
        "artemis-optimise": ArtemisOptimiseWorker,
        "artemis-filter": ArtemisFilterWorker,
    }

    @classmethod
    def task_types(cls) -> list[str]:
        return list(cls.WORKER_MAPPING.keys())

    def __init__(self): ...

    def __call__(self, queued_task: QueuedTask) -> ArtemisUtilityWorker | ArtemisOptimiseWorker | ArtemisFilterWorker:
        return self.get_worker_class(queued_task.taskType)(queued_task)

    def get_worker_class(
        self, runner_id: str
    ) -> Type[ArtemisUtilityWorker] | Type[ArtemisOptimiseWorker] | Type[ArtemisFilterWorker]:
        """
        Runner IDs are usually task_type + some_suffix. This method extracts
        the worker_name so we can use it to get the worker class.
        """
        for task_type, worker in self.WORKER_MAPPING.items():
            if runner_id.startswith(task_type):
                return worker

        raise ValueError(f"Failed to match {runner_id} to one of the task types {self.task_types()}")
